/**
 * Solana聪明钱包筛选器主JavaScript文件
 */

// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', function() {
    // 初始化工具提示
    initTooltips();
    
    // 初始化复制功能
    initCopyButtons();
    
    // 添加地址格式化
    formatAddresses();
});

/**
 * 初始化Bootstrap工具提示
 */
function initTooltips() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

/**
 * 初始化钱包地址复制功能
 */
function initCopyButtons() {
    document.querySelectorAll('.btn-copy').forEach(button => {
        button.addEventListener('click', function() {
            const textToCopy = this.getAttribute('data-clipboard-text');
            
            if (textToCopy) {
                navigator.clipboard.writeText(textToCopy).then(() => {
                    // 临时改变按钮文本
                    const originalText = this.innerHTML;
                    this.innerHTML = '<i class="bi bi-check"></i> 已复制';
                    
                    // 3秒后恢复原始文本
                    setTimeout(() => {
                        this.innerHTML = originalText;
                    }, 3000);
                }).catch(err => {
                    console.error('复制失败:', err);
                });
            }
        });
    });
}

/**
 * 格式化显示地址
 */
function formatAddresses() {
    document.querySelectorAll('.wallet-address-format').forEach(element => {
        const address = element.textContent || element.innerText;
        if (address && address.length > 10) {
            element.textContent = `${address.slice(0, 6)}...${address.slice(-4)}`;
            element.setAttribute('title', address);
            element.classList.add('wallet-address');
        }
    });
}

/**
 * 通用API请求函数
 * @param {string} url - 请求URL
 * @param {string} method - 请求方法 (GET, POST, ...)
 * @param {Object} data - 请求数据 (可选)
 * @returns {Promise} 响应数据的Promise
 */
async function apiRequest(url, method = 'GET', data = null) {
    const options = {
        method,
        headers: {
            'Content-Type': 'application/json'
        }
    };
    
    if (data && (method === 'POST' || method === 'PUT')) {
        options.body = JSON.stringify(data);
    }
    
    try {
        const response = await fetch(url, options);
        
        if (!response.ok) {
            throw new Error(`API请求失败: ${response.status} ${response.statusText}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('API请求错误:', error);
        throw error;
    }
}

/**
 * 通用加载器显示/隐藏
 * @param {string} elementId - 容器元素ID
 * @param {boolean} show - 是否显示加载器
 */
function toggleLoader(elementId, show) {
    const container = document.getElementById(elementId);
    if (!container) return;
    
    if (show) {
        container.innerHTML = `
            <div class="text-center my-5">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">正在加载...</span>
                </div>
                <p class="mt-2">正在加载数据...</p>
            </div>
        `;
    } else {
        // 当需要隐藏加载器时，不执行任何操作
        // 内容将被调用此函数的函数替换
    }
}

/**
 * 通用错误显示
 * @param {string} elementId - 容器元素ID
 * @param {string} message - 错误消息
 */
function showError(elementId, message) {
    const container = document.getElementById(elementId);
    if (!container) return;
    
    container.innerHTML = `
        <div class="alert alert-danger" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            ${message}
        </div>
    `;
}

/**
 * 格式化SOL金额为带单位的字符串
 * @param {number} amount - SOL金额
 * @param {number} decimals - 小数位数
 * @returns {string} 格式化后的金额字符串
 */
function formatSolAmount(amount, decimals = 4) {
    if (amount === null || amount === undefined) return 'N/A';
    
    return amount.toFixed(decimals) + ' SOL';
}

/**
 * 格式化日期时间
 * @param {string} timestamp - ISO格式的时间戳
 * @param {boolean} includeTime - 是否包含时间
 * @returns {string} 格式化后的日期时间
 */
function formatDateTime(timestamp, includeTime = false) {
    if (!timestamp) return 'N/A';
    
    const date = new Date(timestamp);
    
    if (isNaN(date.getTime())) return 'N/A';
    
    const options = {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit'
    };
    
    if (includeTime) {
        options.hour = '2-digit';
        options.minute = '2-digit';
        options.second = '2-digit';
    }
    
    return date.toLocaleString('zh-CN', options);
} 