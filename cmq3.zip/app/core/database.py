from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from app.core.config import get_settings

settings = get_settings()

# 创建SQLAlchemy引擎
engine = create_engine(
    settings.DATABASE_URL, connect_args={"check_same_thread": False}
)

# 创建会话工厂
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# 创建基础类模型
Base = declarative_base()

# 获取数据库会话
def get_db():
    """依赖项：获取数据库会话，使用后自动关闭"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# 初始化数据库
def init_db():
    """创建所有表结构"""
    # 导入所有模型以确保它们被映射
    from app.models.wallet import SmartWallet
    from app.models.transaction import Transaction
    from app.models.token import Token
    from app.models.position import Position
    
    # 创建数据库表
    Base.metadata.create_all(bind=engine) 