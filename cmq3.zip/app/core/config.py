import os
from functools import lru_cache
from pydantic_settings import BaseSettings
from pydantic import Field

class Settings(BaseSettings):
    """应用程序配置设置"""
    
    # 项目名称
    PROJECT_NAME: str = "Solana聪明钱包筛选器"
    
    # Solana链配置
    SOLANA_RPC_URL: str = "https://api.mainnet-beta.solana.com"  # ChainUp节点，国内可访问
    SOLANA_WS_URL: str = "wss://api.mainnet-beta.solana.com"  # ChainUp对应的WebSocket
    
    # 备用节点配置
    # Ankr节点: "https://rpc.ankr.com/solana"
    # 官方节点: "https://api.mainnet-beta.solana.com"
    # Helius节点(需API Key): "https://mainnet.helius-rpc.com/?api-key=YOUR_API_KEY"
    
    # 数据库配置
    DATABASE_URL: str = "sqlite:///./smart_wallets.db"
    
    # Web服务器配置
    HOST: str = "127.0.0.1"
    PORT: int = 9000
    DEBUG: bool = True
    
    # 聪明钱包筛选条件
    WIN_RATE_THRESHOLD: float = 70.0  # 胜率阈值(%)
    PROFIT_LOSS_RATIO: float = 3.0    # 盈亏比
    MIN_DAILY_TRADES: int = 20        # 最小日均交易次数
    MAX_HOLDING_HOURS: int = 24       # 最大持仓时间(小时)
    ANALYSIS_DAYS: int = 30           # 分析周期(天)
    
    # 数据更新频率(分钟)
    DATA_UPDATE_INTERVAL: int = 60
    
    # 缓存设置
    CACHE_TTL: int = 3600  # 缓存过期时间(秒)
    
    # 静态文件配置
    STATIC_DIR: str = "app/static"
    TEMPLATES_DIR: str = "app/templates"
    
    # 数据存储目录
    DATA_DIR: str = "app/data"
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True

@lru_cache()
def get_settings():
    """获取应用配置，使用LRU缓存避免重复加载"""
    return Settings() 