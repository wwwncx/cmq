import asyncio
import datetime
import json
import os
from typing import List, Dict, Any
from sqlalchemy.orm import Session

from app.utils.logger import get_logger
from app.utils.solana import get_solana_connection
from app.core.config import get_settings
from app.core.database import SessionLocal
from app.models.wallet import SmartWallet
from app.services.transaction_analyzer import get_transaction_analyzer

logger = get_logger()
settings = get_settings()

class WalletScanner:
    """钱包扫描器 - 定期扫描和发现新的钱包"""
    
    def __init__(self):
        self.solana = get_solana_connection()
        self.running = False
        self.seed_wallets = self._load_seed_wallets()
        self.known_wallets = set()
        
    def _load_seed_wallets(self) -> List[str]:
        """加载种子钱包列表"""
        # 从文件加载已知的活跃钱包作为起点
        seed_file = os.path.join(settings.DATA_DIR, "seed_wallets.json")
        
        if os.path.exists(seed_file):
            try:
                with open(seed_file, "r") as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"加载种子钱包失败: {e}")
        
        # 默认种子钱包（这里应替换为实际已知的活跃钱包）
        return [
            "3Ah19FKcAS8enWv8iwpaZXqmHbdY5Kh29GCCNgUUNQma",  # 示例钱包地址
            "9TQ1QV3Ym6gDzi3sFpYwZNpVjvweZSTkayPrBANshvos"
        ]
    
    def _save_seed_wallets(self, wallets: List[str]) -> None:
        """保存种子钱包列表"""
        try:
            seed_file = os.path.join(settings.DATA_DIR, "seed_wallets.json")
            os.makedirs(os.path.dirname(seed_file), exist_ok=True)
            with open(seed_file, "w") as f:
                json.dump(wallets, f, indent=2)
        except Exception as e:
            logger.error(f"保存种子钱包失败: {e}")
    
    async def start(self) -> None:
        """启动钱包扫描器"""
        if self.running:
            return
            
        self.running = True
        logger.info("启动钱包扫描器")
        
        while self.running:
            try:
                await self._scan_cycle()
                
                # 等待下一个扫描周期
                await asyncio.sleep(settings.DATA_UPDATE_INTERVAL * 60)
            except Exception as e:
                logger.error(f"扫描周期出错: {e}")
                await asyncio.sleep(60)  # 出错后暂停1分钟再继续
    
    async def stop(self) -> None:
        """停止钱包扫描器"""
        self.running = False
        logger.info("停止钱包扫描器")
    
    async def _scan_cycle(self) -> None:
        """执行一个扫描周期"""
        logger.info("开始新的扫描周期")
        
        # 创建数据库会话
        db = SessionLocal()
        try:
            # 加载已知的钱包
            if not self.known_wallets:
                wallets = db.query(SmartWallet.address).all()
                self.known_wallets = set(w.address for w in wallets)
                
            # 处理种子钱包
            for address in self.seed_wallets:
                await self._process_wallet(db, address)
                
            # 查找更多聪明钱包
            await self._discover_wallets(db)
                
            # 更新种子钱包列表
            smart_wallets = db.query(SmartWallet).filter(SmartWallet.is_smart_wallet == True).all()
            if smart_wallets:
                new_seeds = [w.address for w in smart_wallets[:50]]  # 取前50个作为新种子
                self.seed_wallets = new_seeds
                self._save_seed_wallets(new_seeds)
                
        finally:
            db.close()
    
    async def _process_wallet(self, db: Session, address: str) -> None:
        """处理单个钱包"""
        try:
            # 创建交易分析器
            analyzer = get_transaction_analyzer(db)
            
            # 分析钱包
            wallet = await analyzer.analyze_wallet(address)
            
            # 如果是新钱包，加入已知列表
            if wallet and wallet.address not in self.known_wallets:
                self.known_wallets.add(wallet.address)
                
        except Exception as e:
            logger.error(f"处理钱包 {address} 出错: {e}")
    
    async def _discover_wallets(self, db: Session) -> None:
        """发现新的钱包"""
        try:
            # 查询已知的聪明钱包最近交易，找出与它们交易的新钱包
            smart_wallets = db.query(SmartWallet).filter(SmartWallet.is_smart_wallet == True).limit(10).all()
            
            for wallet in smart_wallets:
                # 获取钱包的最近交易
                recent_txs = await self.solana.get_recent_transactions(wallet.address, limit=20)
                
                # 从交易中提取相关联的钱包
                for tx_info in recent_txs:
                    signature = tx_info.get("signature")
                    if not signature:
                        continue
                        
                    tx_detail = await self.solana.get_transaction(signature)
                    if not tx_detail:
                        continue
                        
                    # 提取交易涉及的账户
                    accounts = self._extract_accounts_from_tx(tx_detail)
                    
                    # 处理新发现的钱包
                    for account in accounts:
                        if account not in self.known_wallets:
                            await self._process_wallet(db, account)
        
        except Exception as e:
            logger.error(f"发现钱包过程中出错: {e}")
    
    def _extract_accounts_from_tx(self, tx_detail: Dict[str, Any]) -> List[str]:
        """从交易详情中提取相关账户"""
        accounts = []
        
        # 实际实现应分析交易指令和账户数组
        # 这里简化为提取meta中的账户前锁数组(pre.keys)
        try:
            if "meta" in tx_detail and "preTokenBalances" in tx_detail["meta"]:
                for balance in tx_detail["meta"]["preTokenBalances"]:
                    if "owner" in balance and balance["owner"] not in accounts:
                        accounts.append(balance["owner"])
        except Exception:
            pass
            
        return accounts

# 单例扫描器
_scanner = None

def get_wallet_scanner():
    """获取钱包扫描器单例"""
    global _scanner
    if _scanner is None:
        _scanner = WalletScanner()
    return _scanner

async def start_scanner():
    """启动钱包扫描器的后台任务"""
    scanner = get_wallet_scanner()
    await scanner.start() 