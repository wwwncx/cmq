import json
import datetime
from typing import List, Dict, Any, Optional, Tuple
from sqlalchemy.orm import Session
import pandas as pd
import numpy as np

from app.utils.logger import get_logger
from app.utils.solana import get_solana_connection
from app.core.config import get_settings
from app.models.wallet import SmartWallet
from app.models.transaction import Transaction
from app.models.token import Token
from app.models.position import Position

logger = get_logger()
settings = get_settings()

class TransactionAnalyzer:
    """交易分析器 - 分析钱包交易数据并判断是否为聪明钱包"""
    
    def __init__(self, db: Session):
        self.db = db
        self.solana = get_solana_connection()
    
    async def analyze_wallet(self, address: str) -> Optional[SmartWallet]:
        """分析钱包数据并确定是否为聪明钱包"""
        logger.info(f"开始分析钱包: {address}")
        
        # 检查钱包是否已存在
        wallet = self.db.query(SmartWallet).filter(SmartWallet.address == address).first()
        if not wallet:
            wallet = SmartWallet(address=address)
            self.db.add(wallet)
        
        # 获取钱包余额
        balance = await self.solana.get_balance(address)
        wallet.balance = balance
        
        # 获取最近的交易数据
        recent_txs = await self.solana.get_recent_transactions(address, limit=1000)
        
        # 分析交易数据
        transactions = await self._process_transactions(wallet, recent_txs)
        
        # 计算统计指标
        self._calculate_wallet_metrics(wallet, transactions)
        
        # 更新钱包统计数据
        wallet.update_stats()
        self.db.commit()
        
        logger.info(f"钱包分析完成: {address}, 是否聪明钱包: {wallet.is_smart_wallet}")
        return wallet
    
    async def _process_transactions(self, wallet: SmartWallet, tx_data: List[Dict[str, Any]]) -> List[Transaction]:
        """处理交易数据，解析并保存到数据库"""
        transactions = []
        
        # 分析周期（过去30天）
        cutoff_date = datetime.datetime.now() - datetime.timedelta(days=settings.ANALYSIS_DAYS)
        
        for tx_info in tx_data:
            # 只处理成功的交易
            if tx_info.get("err") is not None:
                continue
            
            # 获取交易签名
            signature = tx_info.get("signature")
            
            # 检查是否已有这笔交易
            existing_tx = self.db.query(Transaction).filter(Transaction.signature == signature).first()
            if existing_tx:
                transactions.append(existing_tx)
                continue
            
            # 获取交易详情
            tx_detail = await self.solana.get_transaction(signature)
            if not tx_detail:
                continue
                
            # 解析时间戳
            block_time = tx_detail.get("blockTime")
            if not block_time:
                continue
                
            timestamp = datetime.datetime.fromtimestamp(block_time)
            
            # 只分析分析周期内的交易
            if timestamp < cutoff_date:
                continue
            
            # 解析交易类型和代币信息
            tx_type, token_info = self._parse_transaction_type(tx_detail)
            if not tx_type or not token_info:
                continue
                
            # 创建交易记录
            tx = Transaction(
                signature=signature,
                wallet_address=wallet.address,
                tx_type=tx_type,
                token_address=token_info.get("address"),
                token_symbol=token_info.get("symbol", "未知"),
                amount=token_info.get("amount", 0),
                value_in_sol=token_info.get("value_in_sol", 0),
                timestamp=timestamp,
                block_time=block_time,
                block_num=tx_detail.get("slot"),
                fee=tx_detail.get("meta", {}).get("fee", 0) / 1_000_000_000,  # 转换为SOL
                raw_data=json.dumps(tx_detail)
            )
            
            # 处理代币信息
            self._process_token(tx.token_address, tx.token_symbol)
            
            # 更新钱包持仓
            profit_loss = self._update_position(wallet, tx)
            tx.profit_loss = profit_loss
            tx.is_profitable = profit_loss > 0
            
            # 保存交易
            self.db.add(tx)
            transactions.append(tx)
            
            # 更新钱包的最后活动时间
            wallet.last_active = timestamp
        
        self.db.commit()
        return transactions
    
    def _parse_transaction_type(self, tx_detail: Dict[str, Any]) -> Tuple[Optional[str], Optional[Dict[str, Any]]]:
        """解析交易类型和代币信息"""
        # 这里简化了交易类型识别逻辑
        # 实际项目中需要更复杂的解析逻辑来识别不同类型的交易和代币
        
        # 模拟交易类型识别
        # 随机返回交易类型，实际中应根据交易指令和账户分析
        tx_type = "swap"  # 假设为交换交易
        
        # 模拟代币信息
        token_info = {
            "address": "TokenXYZ123",  # 实际应为代币地址
            "symbol": "XYZ",           # 代币符号
            "amount": 100,             # 代币数量
            "value_in_sol": 1.5        # SOL价值
        }
        
        return tx_type, token_info
    
    def _process_token(self, token_address: str, token_symbol: str) -> None:
        """处理代币信息，更新或创建代币记录"""
        if not token_address:
            return
            
        token = self.db.query(Token).filter(Token.address == token_address).first()
        if not token:
            token = Token(
                address=token_address,
                symbol=token_symbol,
                last_seen=datetime.datetime.utcnow()
            )
            self.db.add(token)
        else:
            token.last_seen = datetime.datetime.utcnow()
            token.smart_wallet_trades += 1
            
        self.db.commit()
    
    def _update_position(self, wallet: SmartWallet, transaction: Transaction) -> float:
        """更新钱包持仓信息，计算并返回盈亏"""
        # 查找或创建持仓记录
        position = self.db.query(Position).filter(
            Position.wallet_address == wallet.address,
            Position.token_address == transaction.token_address
        ).first()
        
        if not position:
            position = Position(
                wallet_address=wallet.address,
                token_address=transaction.token_address,
                token_symbol=transaction.token_symbol
            )
            self.db.add(position)
        
        profit_loss = 0.0
        now = datetime.datetime.utcnow()
        
        # 根据交易类型更新持仓
        if transaction.tx_type == "buy":
            # 买入交易
            if position.amount == 0:
                # 新建仓位
                position.avg_buy_price = transaction.value_in_sol / transaction.amount
                position.first_buy_time = position.first_buy_time or transaction.timestamp
            else:
                # 增加现有仓位
                total_cost = (position.amount * position.avg_buy_price) + transaction.value_in_sol
                total_amount = position.amount + transaction.amount
                position.avg_buy_price = total_cost / total_amount
            
            position.amount += transaction.amount
            position.cost_basis = position.amount * position.avg_buy_price
            position.buy_count += 1
            position.last_buy_time = transaction.timestamp
            
        elif transaction.tx_type == "sell":
            # 卖出交易
            if position.amount <= 0:
                # 没有持仓，无法计算盈亏
                return 0.0
                
            # 计算卖出部分的成本
            sell_ratio = min(transaction.amount / position.amount, 1.0)
            sell_cost = position.cost_basis * sell_ratio
            
            # 计算盈亏
            sell_value = transaction.value_in_sol
            profit_loss = sell_value - sell_cost
            
            # 更新持仓
            position.amount -= transaction.amount
            if position.amount <= 0:
                position.amount = 0
                position.cost_basis = 0
            else:
                position.cost_basis = position.amount * position.avg_buy_price
                
            # 更新卖出统计
            position.sell_count += 1
            position.first_sell_time = position.first_sell_time or transaction.timestamp
            position.last_sell_time = transaction.timestamp
            
            # 更新已实现盈亏
            if profit_loss > 0:
                position.realized_profit += profit_loss
            else:
                position.realized_loss += abs(profit_loss)
        
        # 更新持仓统计
        position.update_stats()
        
        return profit_loss
    
    def _calculate_wallet_metrics(self, wallet: SmartWallet, transactions: List[Transaction]) -> None:
        """计算钱包指标：胜率、盈亏比、交易频率、持仓时间"""
        # 转换为DataFrame进行分析
        if not transactions:
            return
            
        # 重置计数
        wallet.total_trades = 0
        wallet.winning_trades = 0
        wallet.total_profit = 0.0
        wallet.total_loss = 0.0
        
        # 计算交易统计
        for tx in transactions:
            wallet.total_trades += 1
            
            if tx.is_profitable:
                wallet.winning_trades += 1
                wallet.total_profit += tx.profit_loss
            elif tx.profit_loss < 0:
                wallet.total_loss += abs(tx.profit_loss)
        
        # 计算日均交易次数
        date_range = (wallet.last_active - wallet.first_seen).days
        if date_range > 0:
            wallet.daily_trades = wallet.total_trades / date_range
        
        # 计算平均持仓时间
        positions = self.db.query(Position).filter(Position.wallet_address == wallet.address).all()
        if positions:
            total_hours = sum(p.avg_holding_time or 0 for p in positions if p.avg_holding_time)
            if total_hours > 0:
                wallet.avg_holding_time = total_hours / len(positions)

# 创建分析器工厂函数
def get_transaction_analyzer(db: Session):
    """获取交易分析器实例"""
    return TransactionAnalyzer(db) 