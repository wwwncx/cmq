"""
模拟数据服务 - 提供测试数据，用于演示或无法连接RPC节点时使用
"""

import datetime
import random
import json
import os
from typing import List, Dict, Any, Optional

from app.models.wallet import SmartWallet
from app.core.config import get_settings

settings = get_settings()

class MockDataService:
    """模拟数据服务 - 生成假数据用于测试和演示"""
    
    def __init__(self):
        self.wallets = []
        self.transactions = []
        self._load_or_generate_data()
    
    def _load_or_generate_data(self):
        """加载或生成模拟数据"""
        mock_data_file = os.path.join(settings.DATA_DIR, "mock_data.json")
        
        if os.path.exists(mock_data_file):
            try:
                with open(mock_data_file, "r") as f:
                    data = json.load(f)
                    self.wallets = data.get("wallets", [])
                    self.transactions = data.get("transactions", [])
                return
            except Exception:
                pass
        
        # 生成模拟钱包数据
        self._generate_mock_wallets(50)
        self._generate_mock_transactions()
        
        # 保存模拟数据到文件
        os.makedirs(os.path.dirname(mock_data_file), exist_ok=True)
        try:
            with open(mock_data_file, "w") as f:
                json.dump({
                    "wallets": self.wallets,
                    "transactions": self.transactions
                }, f, indent=2)
        except Exception:
            pass
    
    def _generate_mock_wallets(self, count: int):
        """生成模拟钱包数据"""
        for i in range(count):
            # 生成Solana风格的随机地址
            address = ''.join(random.choices('123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz', k=44))
            
            # 模拟钱包统计数据
            win_rate = random.uniform(30, 95)
            profit_loss_ratio = random.uniform(0.5, 8.0)
            daily_trades = random.uniform(5, 50)
            avg_holding_time = random.uniform(2, 48)
            
            # 根据筛选条件设置是否为聪明钱包
            is_smart_wallet = (
                win_rate >= settings.WIN_RATE_THRESHOLD and
                profit_loss_ratio >= settings.PROFIT_LOSS_RATIO and
                daily_trades >= settings.MIN_DAILY_TRADES and
                avg_holding_time <= settings.MAX_HOLDING_HOURS
            )
            
            wallet = {
                "address": address,
                "balance": round(random.uniform(0.1, 100), 4),
                "total_trades": random.randint(50, 500),
                "winning_trades": int(win_rate / 100 * random.randint(50, 500)),
                "win_rate": win_rate,
                "total_profit": round(random.uniform(1, 50), 4),
                "total_loss": round(random.uniform(0.1, 10), 4),
                "profit_loss_ratio": profit_loss_ratio,
                "avg_profit_per_trade": round(random.uniform(0.01, 0.5), 4),
                "daily_trades": daily_trades,
                "avg_holding_time": avg_holding_time,
                "first_seen": (datetime.datetime.now() - datetime.timedelta(days=random.randint(30, 180))).isoformat(),
                "last_active": (datetime.datetime.now() - datetime.timedelta(days=random.randint(0, 10))).isoformat(),
                "last_updated": datetime.datetime.now().isoformat(),
                "is_smart_wallet": is_smart_wallet
            }
            
            self.wallets.append(wallet)
    
    def _generate_mock_transactions(self):
        """为每个钱包生成模拟交易数据"""
        for wallet in self.wallets:
            # 为每个钱包生成10-50笔交易
            tx_count = random.randint(10, 50)
            for i in range(tx_count):
                # 模拟交易类型
                tx_type = random.choice(["buy", "sell", "swap", "transfer"])
                
                # 模拟代币符号
                token_symbol = random.choice(["SOL", "USDC", "BONK", "JTO", "RAY", "SRM", "FIDA", "MNGO"])
                
                # 模拟交易数量
                amount = round(random.uniform(1, 1000), 2)
                
                # 模拟交易价值
                value_in_sol = round(random.uniform(0.1, 10), 4)
                
                # 模拟盈亏
                is_profitable = random.random() > 0.3  # 70%概率盈利
                profit_loss = round(random.uniform(0.01, 2), 4) if is_profitable else round(random.uniform(-1, -0.01), 4)
                
                # 模拟交易哈希
                signature = ''.join(random.choices('0123456789abcdef', k=64))
                
                # 模拟交易时间
                timestamp = (datetime.datetime.now() - datetime.timedelta(days=random.randint(1, 30))).isoformat()
                
                transaction = {
                    "wallet_address": wallet["address"],
                    "signature": signature,
                    "tx_type": tx_type,
                    "token_symbol": token_symbol,
                    "amount": amount,
                    "value_in_sol": value_in_sol,
                    "profit_loss": profit_loss,
                    "is_profitable": is_profitable,
                    "timestamp": timestamp
                }
                
                self.transactions.append(transaction)
    
    def get_wallets(self, smart_only: bool = False, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """获取钱包列表"""
        filtered_wallets = [w for w in self.wallets if not smart_only or w["is_smart_wallet"]]
        return filtered_wallets[offset:offset+limit]
    
    def get_wallet_by_address(self, address: str) -> Optional[Dict[str, Any]]:
        """根据地址获取钱包信息"""
        for wallet in self.wallets:
            if wallet["address"] == address:
                return wallet
        return None
    
    def get_transactions(self, wallet_address: Optional[str] = None, limit: int = 100, offset: int = 0) -> List[Dict[str, Any]]:
        """获取交易列表"""
        if wallet_address:
            filtered_txs = [tx for tx in self.transactions if tx["wallet_address"] == wallet_address]
        else:
            filtered_txs = self.transactions
        
        return filtered_txs[offset:offset+limit]
    
    def get_wallet_stats(self) -> Dict[str, Any]:
        """获取钱包统计信息"""
        smart_wallets = [w for w in self.wallets if w["is_smart_wallet"]]
        
        return {
            "total_wallets": len(self.wallets),
            "smart_wallet_count": len(smart_wallets),
            "avg_win_rate": sum(w["win_rate"] for w in smart_wallets) / len(smart_wallets) if smart_wallets else 0,
            "avg_profit_loss_ratio": sum(w["profit_loss_ratio"] for w in smart_wallets) / len(smart_wallets) if smart_wallets else 0,
            "avg_daily_trades": sum(w["daily_trades"] for w in smart_wallets) / len(smart_wallets) if smart_wallets else 0
        }

# 单例模式
_mock_service = None

def get_mock_service():
    """获取模拟数据服务单例"""
    global _mock_service
    if _mock_service is None:
        _mock_service = MockDataService()
    return _mock_service 