import datetime
from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, ForeignKey, Text
from sqlalchemy.orm import relationship
from app.core.database import Base

class Position(Base):
    """持仓模型 - 记录钱包对特定代币的买入和卖出情况"""
    __tablename__ = "positions"
    
    id = Column(Integer, primary_key=True, index=True)
    wallet_address = Column(String, ForeignKey("smart_wallets.address", ondelete="CASCADE"), index=True)
    token_address = Column(String, index=True)
    token_symbol = Column(String)
    
    # 持仓情况
    amount = Column(Float, default=0.0)  # 当前持有数量
    avg_buy_price = Column(Float)  # 平均买入价格(SOL)
    cost_basis = Column(Float)  # 总成本(SOL)
    
    # 交易统计
    buy_count = Column(Integer, default=0)  # 买入次数
    sell_count = Column(Integer, default=0)  # 卖出次数
    
    # 盈亏
    realized_profit = Column(Float, default=0.0)  # 已实现盈利
    realized_loss = Column(Float, default=0.0)  # 已实现亏损
    
    # 时间跟踪
    first_buy_time = Column(DateTime)  # 首次买入时间
    last_buy_time = Column(DateTime)  # 最近买入时间
    first_sell_time = Column(DateTime)  # 首次卖出时间
    last_sell_time = Column(DateTime)  # 最近卖出时间
    
    # 持仓时间
    avg_holding_time = Column(Float)  # 平均持仓时间(小时)
    
    # 是否活跃
    is_active = Column(Boolean, default=True)  # 是否仍在持有
    last_updated = Column(DateTime, default=datetime.datetime.utcnow)
    
    # 关系
    wallet = relationship("SmartWallet", back_populates="positions")
    
    def update_stats(self):
        """更新持仓统计"""
        # 计算平均持仓时间 (如果有首次买入和最近卖出记录)
        if self.first_buy_time and self.last_sell_time:
            holding_delta = self.last_sell_time - self.first_buy_time
            self.avg_holding_time = holding_delta.total_seconds() / 3600  # 转换为小时
        
        # 更新活跃状态 (如果数量为0，则视为不活跃)
        self.is_active = self.amount > 0
        
        # 更新时间戳
        self.last_updated = datetime.datetime.utcnow()
    
    def to_dict(self):
        """转换为字典"""
        return {
            "id": self.id,
            "wallet_address": self.wallet_address,
            "token_address": self.token_address,
            "token_symbol": self.token_symbol,
            "amount": self.amount,
            "avg_buy_price": self.avg_buy_price,
            "cost_basis": self.cost_basis,
            "buy_count": self.buy_count,
            "sell_count": self.sell_count,
            "realized_profit": self.realized_profit,
            "realized_loss": self.realized_loss,
            "first_buy_time": self.first_buy_time.isoformat() if self.first_buy_time else None,
            "last_buy_time": self.last_buy_time.isoformat() if self.last_buy_time else None,
            "first_sell_time": self.first_sell_time.isoformat() if self.first_sell_time else None,
            "last_sell_time": self.last_sell_time.isoformat() if self.last_sell_time else None,
            "avg_holding_time": self.avg_holding_time,
            "is_active": self.is_active,
            "last_updated": self.last_updated.isoformat() if self.last_updated else None
        } 