import datetime
from sqlalchemy import Column, String, Float, Integer, DateTime, Boolean, ForeignKey, Text
from sqlalchemy.orm import relationship
from app.core.database import Base

class Transaction(Base):
    """交易模型"""
    __tablename__ = "transactions"
    
    id = Column(Integer, primary_key=True, index=True)
    signature = Column(String, unique=True, index=True)
    wallet_address = Column(String, ForeignKey("smart_wallets.address", ondelete="CASCADE"), index=True)
    
    # 交易类型: 'buy', 'sell', 'swap', 'transfer'
    tx_type = Column(String)
    
    # 代币信息
    token_address = Column(String, index=True)
    token_symbol = Column(String)
    
    # 数量和价值
    amount = Column(Float)  # 代币数量
    value_in_sol = Column(Float)  # SOL价值
    
    # 交易结果
    profit_loss = Column(Float, default=0.0)  # 盈亏（SOL）
    is_profitable = Column(Boolean, default=False)  # 是否盈利
    
    # 时间相关
    timestamp = Column(DateTime, index=True)
    block_time = Column(Integer)
    block_num = Column(Integer)
    
    # 链上数据
    fee = Column(Float)  # 交易费用(SOL)
    raw_data = Column(Text)  # 原始交易数据(JSON)
    
    # 关系
    wallet = relationship("SmartWallet", back_populates="transactions")
    
    def to_dict(self):
        """转换为字典"""
        return {
            "id": self.id,
            "signature": self.signature,
            "wallet_address": self.wallet_address,
            "tx_type": self.tx_type,
            "token_address": self.token_address,
            "token_symbol": self.token_symbol,
            "amount": self.amount,
            "value_in_sol": self.value_in_sol,
            "profit_loss": self.profit_loss,
            "is_profitable": self.is_profitable,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
            "block_time": self.block_time,
            "block_num": self.block_num,
            "fee": self.fee
        } 