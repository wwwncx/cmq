import datetime
from sqlalchemy import Column, String, Float, Integer, DateTime, ForeignKey, Boolean
from app.core.database import Base

class Token(Base):
    """代币模型"""
    __tablename__ = "tokens"
    
    address = Column(String, primary_key=True, index=True)
    symbol = Column(String, index=True)
    name = Column(String)
    
    # 代币基本信息
    decimals = Column(Integer, default=0)
    supply = Column(Float)
    
    # 价格数据
    current_price_sol = Column(Float)  # 当前价格(SOL)
    last_price_update = Column(DateTime, default=datetime.datetime.utcnow)
    
    # 统计数据
    smart_wallet_trades = Column(Integer, default=0)  # 聪明钱包交易次数
    is_popular = Column(Boolean, default=False)  # 是否受欢迎(多个聪明钱包交易)
    
    # 首次和最近出现时间
    first_seen = Column(DateTime, default=datetime.datetime.utcnow)
    last_seen = Column(DateTime, default=datetime.datetime.utcnow)
    
    def to_dict(self):
        """转换为字典"""
        return {
            "address": self.address,
            "symbol": self.symbol,
            "name": self.name,
            "decimals": self.decimals,
            "supply": self.supply,
            "current_price_sol": self.current_price_sol,
            "last_price_update": self.last_price_update.isoformat() if self.last_price_update else None,
            "smart_wallet_trades": self.smart_wallet_trades,
            "is_popular": self.is_popular,
            "first_seen": self.first_seen.isoformat() if self.first_seen else None,
            "last_seen": self.last_seen.isoformat() if self.last_seen else None
        } 