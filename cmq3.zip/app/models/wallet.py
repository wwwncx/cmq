import datetime
from sqlalchemy import Column, String, Float, Integer, DateTime, Boolean
from sqlalchemy.orm import relationship
from app.core.database import Base

class SmartWallet(Base):
    """聪明钱包模型"""
    __tablename__ = "smart_wallets"
    
    address = Column(String, primary_key=True, index=True)
    balance = Column(Float, default=0.0)  # SOL余额
    
    # 交易统计
    total_trades = Column(Integer, default=0)  # 总交易数
    winning_trades = Column(Integer, default=0)  # 盈利交易数
    win_rate = Column(Float, default=0.0)  # 胜率(%)
    
    # 盈亏数据
    total_profit = Column(Float, default=0.0)  # 总盈利(SOL)
    total_loss = Column(Float, default=0.0)  # 总亏损(SOL)
    profit_loss_ratio = Column(Float, default=0.0)  # 盈亏比
    avg_profit_per_trade = Column(Float, default=0.0)  # 每笔交易平均盈利
    
    # 交易频率
    daily_trades = Column(Float, default=0.0)  # 日均交易次数
    
    # 持仓时间
    avg_holding_time = Column(Float, default=0.0)  # 平均持仓时间(小时)
    
    # 时间戳
    first_seen = Column(DateTime, default=datetime.datetime.utcnow)
    last_active = Column(DateTime, default=datetime.datetime.utcnow)
    last_updated = Column(DateTime, default=datetime.datetime.utcnow)
    
    # 聪明钱标记
    is_smart_wallet = Column(Boolean, default=False)
    
    # 关联
    transactions = relationship("Transaction", back_populates="wallet", cascade="all, delete-orphan")
    positions = relationship("Position", back_populates="wallet", cascade="all, delete-orphan")
    
    def update_stats(self):
        """更新钱包统计数据"""
        # 更新胜率
        if self.total_trades > 0:
            self.win_rate = (self.winning_trades / self.total_trades) * 100
        
        # 更新盈亏比
        if self.total_loss > 0:
            self.profit_loss_ratio = self.total_profit / self.total_loss
        
        # 更新聪明钱包标记
        from app.core.config import get_settings
        settings = get_settings()
        
        self.is_smart_wallet = (
            self.win_rate >= settings.WIN_RATE_THRESHOLD and
            self.profit_loss_ratio >= settings.PROFIT_LOSS_RATIO and
            self.daily_trades >= settings.MIN_DAILY_TRADES and
            self.avg_holding_time <= settings.MAX_HOLDING_HOURS
        )
        
        # 更新时间戳
        self.last_updated = datetime.datetime.utcnow()
        
    def to_dict(self):
        """转换为字典"""
        return {
            "address": self.address,
            "balance": self.balance,
            "total_trades": self.total_trades,
            "winning_trades": self.winning_trades,
            "win_rate": self.win_rate,
            "total_profit": self.total_profit,
            "total_loss": self.total_loss,
            "profit_loss_ratio": self.profit_loss_ratio,
            "avg_profit_per_trade": self.avg_profit_per_trade,
            "daily_trades": self.daily_trades,
            "avg_holding_time": self.avg_holding_time,
            "first_seen": self.first_seen.isoformat(),
            "last_active": self.last_active.isoformat(),
            "last_updated": self.last_updated.isoformat(),
            "is_smart_wallet": self.is_smart_wallet
        } 