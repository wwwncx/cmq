import asyncio
import aiohttp
import base58  # 添加base58库用于解码
from solana.rpc.async_api import AsyncClient
from solders.pubkey import Pubkey as PublicKey  # 使用solders.pubkey代替solana.publickey
from app.core.config import get_settings
from app.utils.logger import get_logger

logger = get_logger()
settings = get_settings()

class SolanaConnection:
    """Solana链连接管理器"""
    
    def __init__(self, rpc_url=None, ws_url=None, proxy=None, timeout=60):
        """初始化Solana连接
        
        Args:
            rpc_url: 自定义RPC URL，不提供则使用配置中的URL
            ws_url: 自定义WebSocket URL，不提供则使用配置中的URL
            proxy: 代理服务器地址，例如"http://127.0.0.1:7890"
            timeout: 请求超时时间(秒)
        """
        self.rpc_url = rpc_url or settings.SOLANA_RPC_URL
        self.ws_url = ws_url or settings.SOLANA_WS_URL
        self.proxy = proxy
        self.timeout = timeout
            
        # 配置客户端选项
        client_options = {}
        if self.proxy:
            client_options["proxy"] = self.proxy
        
        # 创建HTTP会话（用于初始测试连接）
        self.session = None
        
        # 创建客户端
        self.client = AsyncClient(self.rpc_url, timeout=self.timeout, **client_options)
        logger.info(f"初始化Solana连接: {self.rpc_url}" + (f" (使用代理: {self.proxy})" if self.proxy else ""))
    
    async def get_client(self):
        """获取Solana客户端"""
        return self.client
    
    async def get_session(self):
        """获取或创建HTTP会话"""
        if self.session is None or self.session.closed:
            # 创建连接器和会话
            try:
                # 首先尝试禁用SSL验证
                connector = aiohttp.TCPConnector(ssl=False)
                session_options = {"connector": connector}
                
                if self.proxy:
                    session_options["proxy"] = self.proxy
                
                self.session = aiohttp.ClientSession(**session_options)
                logger.info("创建了一个不验证SSL的HTTP会话")
            except Exception as e:
                logger.warning(f"创建不验证SSL的HTTP会话失败: {e}")
                # 如果失败，尝试创建普通会话
                session_options = {}
                if self.proxy:
                    session_options["proxy"] = self.proxy
                self.session = aiohttp.ClientSession(**session_options)
                logger.info("创建了一个普通HTTP会话")
                
        return self.session
    
    async def close(self):
        """关闭所有连接"""
        if self.session and not self.session.closed:
            await self.session.close()
        await self.client.close()
        logger.info("Solana连接已关闭")
    
    async def get_account_info(self, address):
        """获取账户信息"""
        try:
            # 将字符串地址转换为PublicKey对象
            pubkey = PublicKey.from_string(address)  # 使用from_string方法
            response = await self.client.get_account_info(pubkey)
            if "result" in response and "value" in response["result"]:
                return response["result"]["value"]
            else:
                logger.warning(f"获取账户信息格式异常: {response}")
                return None
        except Exception as e:
            logger.error(f"获取账户信息出错: {e}")
            return None
    
    async def get_balance(self, address):
        """获取SOL余额"""
        try:
            # 将字符串地址转换为PublicKey对象
            pubkey = PublicKey.from_string(address)  # 使用from_string方法
            response = await self.client.get_balance(pubkey)
            # 转换为SOL (层面单位换算: lamports -> SOL)
            if "result" in response and "value" in response["result"]:
                return float(response["result"]["value"]) / 1_000_000_000
            else:
                logger.warning(f"获取余额格式异常: {response}")
                return 0.0
        except Exception as e:
            logger.error(f"获取余额出错: {e}")
            return 0.0
    
    async def get_recent_transactions(self, address, limit=100):
        """获取最近交易"""
        try:
            # 将字符串地址转换为PublicKey对象
            pubkey = PublicKey.from_string(address)  # 使用from_string方法
            # 使用签名查询
            response = await self.client.get_signatures_for_address(pubkey, limit=limit)
            if "result" in response:
                return response["result"]
            else:
                logger.warning(f"获取交易历史格式异常: {response}")
                return []
        except Exception as e:
            logger.error(f"获取交易历史出错: {e}")
            return []
    
    async def get_transaction(self, signature):
        """获取交易详情"""
        try:
            response = await self.client.get_transaction(signature)
            if "result" in response:
                return response["result"]
            else:
                logger.warning(f"获取交易详情格式异常: {response}")
                return None
        except Exception as e:
            logger.error(f"获取交易详情出错: {e}")
            return None
    
    async def test_connection(self):
        """测试连接是否正常"""
        try:
            # 尝试使用HTTP会话直接访问RPC URL
            session = await self.get_session()
            async with session.post(self.rpc_url, json={"jsonrpc": "2.0", "id": 1, "method": "getVersion"}, timeout=self.timeout) as response:
                if response.status == 200:
                    res_data = await response.json()
                    if "result" in res_data:
                        return True, f"连接正常，版本: {res_data['result']}"
                    else:
                        return False, f"连接异常: {res_data}"
                else:
                    return False, f"连接HTTP状态异常: {response.status}"
        except Exception as e:
            logger.error(f"直接HTTP连接测试失败: {e}")
            
            # 如果HTTP直接访问失败，尝试使用客户端API
            try:
                response = await self.client.get_version()
                if "result" in response:
                    return True, f"连接正常，版本: {response['result']}"
                else:
                    return False, f"连接异常: {response}"
            except Exception as e2:
                logger.error(f"客户端API连接测试失败: {e2}")
                
                # 最后尝试获取当前slot
                try:
                    response = await self.client.get_slot()
                    if "result" in response:
                        return True, f"连接正常，当前slot: {response['result']}"
                    else:
                        return False, f"连接异常: {response}"
                except Exception as e3:
                    return False, f"连接错误，所有方法都失败: {e3}"

# 单例连接实例
_solana_connection = None

def get_solana_connection(proxy=None):
    """获取Solana连接单例
    
    Args:
        proxy: 可选的代理服务器地址
    
    Returns:
        SolanaConnection实例
    """
    global _solana_connection
    if _solana_connection is None:
        _solana_connection = SolanaConnection(proxy=proxy)
    return _solana_connection 