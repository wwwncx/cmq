import logging
import os
import sys
from logging.handlers import RotatingFileHandler

# 确保日志目录存在
os.makedirs("logs", exist_ok=True)

# 创建日志记录器
logger = logging.getLogger("solana_smart_wallet")
logger.setLevel(logging.INFO)

# 日志格式
log_format = logging.Formatter(
    "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

# 控制台处理器
console_handler = logging.StreamHandler(sys.stdout)
console_handler.setFormatter(log_format)
logger.addHandler(console_handler)

# 文件处理器(5MB, 最多5个备份)
file_handler = RotatingFileHandler(
    "logs/smart_wallet.log",
    maxBytes=5 * 1024 * 1024,
    backupCount=5
)
file_handler.setFormatter(log_format)
logger.addHandler(file_handler)

def get_logger():
    """获取应用日志记录器"""
    return logger 