from fastapi import APIRouter, Request, Depends, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
import os

from app.core.config import get_settings
from app.core.database import get_db
from app.models.wallet import SmartWallet

settings = get_settings()
templates = Jinja2Templates(directory=settings.TEMPLATES_DIR)

router = APIRouter(tags=["dashboard"])

@router.get("/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request, db: Session = Depends(get_db)):
    """展示仪表盘页面"""
    # 获取聪明钱包数量
    smart_wallet_count = db.query(SmartWallet).filter(SmartWallet.is_smart_wallet == True).count()
    
    # 获取前10个聪明钱包
    top_wallets = db.query(SmartWallet)\
        .filter(SmartWallet.is_smart_wallet == True)\
        .order_by(SmartWallet.profit_loss_ratio.desc())\
        .limit(10).all()
    
    return templates.TemplateResponse(
        "dashboard.html", 
        {
            "request": request, 
            "smart_wallet_count": smart_wallet_count,
            "top_wallets": [w.to_dict() for w in top_wallets]
        }
    )

@router.get("/wallet/{address}", response_class=HTMLResponse)
async def wallet_detail(address: str, request: Request, db: Session = Depends(get_db)):
    """展示钱包详情页面"""
    wallet = db.query(SmartWallet).filter(SmartWallet.address == address).first()
    if not wallet:
        raise HTTPException(status_code=404, detail="钱包未找到")
        
    return templates.TemplateResponse(
        "wallet_detail.html", 
        {
            "request": request, 
            "wallet": wallet.to_dict()
        }
    ) 