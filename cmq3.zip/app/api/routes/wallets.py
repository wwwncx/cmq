from fastapi import APIRouter, Depends, HTTPException, Query
from typing import List, Optional
from sqlalchemy.orm import Session
from sqlalchemy import desc, func

from app.core.database import get_db
from app.models.wallet import SmartWallet
from app.services.transaction_analyzer import get_transaction_analyzer

router = APIRouter()

@router.get("/", response_model=List[dict])
async def get_wallets(
    smart_only: bool = Query(False, description="仅返回聪明钱包"),
    min_win_rate: Optional[float] = Query(None, description="最小胜率"),
    min_profit_ratio: Optional[float] = Query(None, description="最小盈亏比"),
    min_daily_trades: Optional[float] = Query(None, description="最小日均交易次数"),
    max_holding_hours: Optional[float] = Query(None, description="最大持仓时间(小时)"),
    limit: int = Query(100, description="返回条数限制"),
    offset: int = Query(0, description="分页偏移量"),
    db: Session = Depends(get_db)
):
    """获取钱包列表，支持筛选"""
    query = db.query(SmartWallet)
    
    # 应用筛选条件
    if smart_only:
        query = query.filter(SmartWallet.is_smart_wallet == True)
    if min_win_rate is not None:
        query = query.filter(SmartWallet.win_rate >= min_win_rate)
    if min_profit_ratio is not None:
        query = query.filter(SmartWallet.profit_loss_ratio >= min_profit_ratio)
    if min_daily_trades is not None:
        query = query.filter(SmartWallet.daily_trades >= min_daily_trades)
    if max_holding_hours is not None:
        query = query.filter(SmartWallet.avg_holding_time <= max_holding_hours)
    
    # 按盈亏比降序排序
    query = query.order_by(desc(SmartWallet.profit_loss_ratio))
    
    # 应用分页
    wallets = query.offset(offset).limit(limit).all()
    
    return [wallet.to_dict() for wallet in wallets]

@router.get("/{address}", response_model=dict)
async def get_wallet_detail(address: str, db: Session = Depends(get_db)):
    """获取钱包详情"""
    wallet = db.query(SmartWallet).filter(SmartWallet.address == address).first()
    if not wallet:
        raise HTTPException(status_code=404, detail="钱包未找到")
        
    return wallet.to_dict()

@router.post("/{address}/analyze", response_model=dict)
async def analyze_wallet(address: str, db: Session = Depends(get_db)):
    """手动分析钱包"""
    analyzer = get_transaction_analyzer(db)
    wallet = await analyzer.analyze_wallet(address)
    
    if not wallet:
        raise HTTPException(status_code=404, detail="钱包分析失败")
        
    return wallet.to_dict()

@router.get("/stats/overview", response_model=dict)
async def get_wallet_stats(db: Session = Depends(get_db)):
    """获取钱包统计概览"""
    # 总钱包数
    total_wallets = db.query(SmartWallet).count()
    
    # 聪明钱包数
    smart_wallets = db.query(SmartWallet).filter(SmartWallet.is_smart_wallet == True).count()
    
    # 平均胜率
    result = db.query(
        func.avg(SmartWallet.win_rate).label("avg_win_rate")
    ).filter(SmartWallet.total_trades > 0).first()
    avg_win_rate = result.avg_win_rate if result else 0
    
    # 平均盈亏比
    result = db.query(
        func.avg(SmartWallet.profit_loss_ratio).label("avg_profit_loss_ratio")
    ).filter(SmartWallet.total_loss > 0).first()
    avg_profit_loss_ratio = result.avg_profit_loss_ratio if result else 0
    
    return {
        "total_wallets": total_wallets,
        "smart_wallets": smart_wallets,
        "smart_wallet_percentage": (smart_wallets / total_wallets * 100) if total_wallets > 0 else 0,
        "avg_win_rate": avg_win_rate,
        "avg_profit_loss_ratio": avg_profit_loss_ratio
    } 