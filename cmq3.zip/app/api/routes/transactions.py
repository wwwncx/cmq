from fastapi import APIRouter, Depends, HTTPException, Query
from typing import List, Optional
from sqlalchemy.orm import Session
from sqlalchemy import desc

from app.core.database import get_db
from app.models.transaction import Transaction
from app.models.position import Position

router = APIRouter()

@router.get("/", response_model=List[dict])
async def get_transactions(
    wallet_address: Optional[str] = Query(None, description="钱包地址筛选"),
    token_address: Optional[str] = Query(None, description="代币地址筛选"),
    tx_type: Optional[str] = Query(None, description="交易类型筛选(buy, sell, swap, transfer)"),
    is_profitable: Optional[bool] = Query(None, description="是否盈利筛选"),
    limit: int = Query(100, description="返回条数限制"),
    offset: int = Query(0, description="分页偏移量"),
    db: Session = Depends(get_db)
):
    """获取交易列表，支持筛选"""
    query = db.query(Transaction)
    
    # 应用筛选条件
    if wallet_address:
        query = query.filter(Transaction.wallet_address == wallet_address)
    if token_address:
        query = query.filter(Transaction.token_address == token_address)
    if tx_type:
        query = query.filter(Transaction.tx_type == tx_type)
    if is_profitable is not None:
        query = query.filter(Transaction.is_profitable == is_profitable)
    
    # 按时间戳降序排序
    query = query.order_by(desc(Transaction.timestamp))
    
    # 应用分页
    transactions = query.offset(offset).limit(limit).all()
    
    return [tx.to_dict() for tx in transactions]

@router.get("/{signature}", response_model=dict)
async def get_transaction_detail(signature: str, db: Session = Depends(get_db)):
    """获取交易详情"""
    tx = db.query(Transaction).filter(Transaction.signature == signature).first()
    if not tx:
        raise HTTPException(status_code=404, detail="交易未找到")
        
    return tx.to_dict()

@router.get("/wallet/{wallet_address}/positions", response_model=List[dict])
async def get_wallet_positions(
    wallet_address: str,
    active_only: bool = Query(False, description="仅返回活跃持仓"),
    db: Session = Depends(get_db)
):
    """获取钱包持仓列表"""
    query = db.query(Position).filter(Position.wallet_address == wallet_address)
    
    if active_only:
        query = query.filter(Position.is_active == True)
    
    positions = query.all()
    return [pos.to_dict() for pos in positions] 