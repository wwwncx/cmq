from fastapi import FastAPI, Request, Depends
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session
import os

from app.core.config import get_settings
from app.core.database import get_db, init_db
from app.api.routes import wallets, transactions, dashboard

settings = get_settings()

# 创建FastAPI应用
app = FastAPI(
    title=settings.PROJECT_NAME,
    description="Solana链聪明钱包筛选工具",
    version="1.0.0"
)

# 挂载静态文件
if os.path.exists(settings.STATIC_DIR):
    app.mount("/static", StaticFiles(directory=settings.STATIC_DIR), name="static")

# 设置模板
templates = Jinja2Templates(directory=settings.TEMPLATES_DIR)

# 注册路由
app.include_router(dashboard.router)
app.include_router(wallets.router, prefix="/api/wallets", tags=["wallets"])
app.include_router(transactions.router, prefix="/api/transactions", tags=["transactions"])

@app.get("/", response_class=HTMLResponse)
async def root(request: Request, db: Session = Depends(get_db)):
    """主页"""
    return templates.TemplateResponse("index.html", {"request": request}) 